# SNMP
```bash
sudo ip addr add 10.0.0.122/30 dev eth0
sudo ip link set eth0 up
sudo ip route add default via 10.0.0.121
```
